function yout=starting_method(y0,h,f)
% y0 is the initial condition
% h is the step size
% f is the RHS of the ODE
%nfs is the number of function evaluatons

global nfs

% The starting A matrix is 
As=[0 0 0 0 ; 1/2 0 0 0 ; 0 1/2 0 0 ; 0 0 1 0  ];

% The starting B matrix is 
Bs=[           0                   0                   0                   0;
  -0.203599283611326   0.093013520189574   0.079026915254744   0.031558848167008;
  -0.523240277404552   0.399628138816171   0.388537971512798  -0.264925832924417];


% The stages are 
Y1=y0;
Y2=y0+h*As(2,1)*f(Y1);
Y3=y0+h*As(3,2)*f(Y2);
Y4=y0+h*As(4,3)*f(Y3);

% The output values are 
y1=h*Bs(2,1)*f(Y1)+ h*Bs(2,2)*f(Y2) + h*Bs(2,3)*f(Y3)+h*Bs(2,4)*f(Y4);
y2=h*Bs(3,1)*f(Y1)+ h*Bs(3,2)*f(Y2) + h*Bs(3,3)*f(Y3)+h*Bs(3,4)*f(Y4);

nfs=nfs+11

yout=[y0,y1,y2]


