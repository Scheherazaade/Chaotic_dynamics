function [yout tout ]=actual_method(y0,h,f,J,n)
% y0 is the initial condition
% h is the step size
% f is the RHS of the ODE
% J is the Jacobian 
% n is the number of steps
% nfs is the number of function evaluations

% The actual General Linear Method is 
A =[ 0 0 0  0; -11/172 1/4 0 0;  -2647/72240 1009/1680 1/4 0;  -169/1680 113821/283920 473/676 0];
U =[ 1 1/4 (1/4)*sqrt(3) ;1 -(1973/29068)+(2/7267)*sqrt(3)*sqrt(14595) -(2/7267)*sqrt(14595)-(1973/29068)*sqrt(3); 1  (1973/29068)-(2/7267)*sqrt(3)*sqrt(14595) (2/7267)*sqrt(14595)+(1973/29068)*sqrt(3); 1 -1/4 -(1/4)*sqrt(3)];
B =[  -169/3360 1849/3360 1849/3360 -169/3360;  -169/1680 -84839/283920 84839/283920 169/1680; 0 -(43/35490)*sqrt(14595) (43/35490)*sqrt(14595) 0];
V =[ 1 0 0; 0 -1/2 -(1/2)*sqrt(3); 0 (1/2)*sqrt(3) -1/2];

% The input to the actual method is 
yin = starting_method(y0,h,f);

% The output from the actual method is calculated by first calculating the
% stages. The first and last stage is explicit and we employ Newton method
% for the implicit second and third stage.

global nfs
sz = size(y0);
I = eye(sz(1));
yfin=[];
t=0;
t1=[];


for i=1:n;
i
% The first stage is
Y1=U(1,1)*yin(:,1)+U(1,2)*yin(:,2)+U(1,3)*yin(:,3);

%The second stage is 
Y2=y0;

for it = 1: 100;
  
l = (A(2,2)*h*J(Y2)-I);
r = U(2,1)*yin(:,1)+U(2,2)*yin(:,2)+U(2,3)*yin(:,3)+A(2,1)*h*f(Y1)+A(2,2)*h*f(Y2)-Y2;
dY2 = l\r;
Y2c = Y2-dY2;

nfs=nfs+3;

 if norm(Y2c-Y2)<0.0000000001;
    nfs=nfs-3; 
 break
 end
 Y2 = Y2c;
end
Y2 = Y2c;


%The third stage is 
Y3=y0;

for it = 1: 100;
    
l = (A(3,3)*h*J(Y3)-I);
r = U(3,1)*yin(:,1)+U(3,2)*yin(:,2)+U(3,3)*yin(:,3)+A(3,1)*h*f(Y1)+A(3,2)*h*f(Y2)+A(3,3)*h*f(Y3)-Y3;
dY3 = l\r;
Y3c = Y3-dY3;
  nfs=nfs+4; 
if norm(Y3c-Y3)<0.0000000001;
     nfs=nfs-4; 
 break
 end
 Y3 = Y3c;
end
Y3 = Y3c;

% The fourth stage is 
Y4=A(4,1)*h*f(Y1)+A(4,2)*h*f(Y2)+A(4,3)*h*f(Y3)+U(4,1)*yin(:,1)+U(4,2)*yin(:,2)+U(4,3)*yin(:,3);


% the output from the actual method is 
 yout_1 = V(1,1)*yin(:,1) + V(1,2)*yin(:,2) + V(1,3)*yin(:,3) + B(1,1)*h*f(Y1)+B(1,2)*h*f(Y2)+ B(1,3)*h*f(Y3)+ B(1,4)*h*f(Y4);
 yout_2 = V(2,1)*yin(:,1) + V(2,2)*yin(:,2) + V(2,3)*yin(:,3) + B(2,1)*h*f(Y1)+B(2,2)*h*f(Y2)+ B(2,3)*h*f(Y3)+ B(2,4)*h*f(Y4);
 yout_3 = V(3,1)*yin(:,1) + V(3,2)*yin(:,2) + V(3,3)*yin(:,3) + B(3,1)*h*f(Y1)+B(3,2)*h*f(Y2)+ B(3,3)*h*f(Y3)+ B(3,4)*h*f(Y4);

 yin=[yout_1 yout_2  yout_3];
 
 %yfin=[yfin yout_1];
yfin=[yfin [yout_1;yout_2;yout_3]];
  nfs=nfs+15;
t=t+h;
t1=[t1 t];

 
end

yout=yfin;
tout=t1;
nfs

